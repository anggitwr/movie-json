package com.anggit.subflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
